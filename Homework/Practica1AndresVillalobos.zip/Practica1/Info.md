# Practica 1
## Fecha: 25-5-2023
Estructuras de datos 1
Andres Villalobos Carballo
1-1886-0295